﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;


namespace DiscountManagement.Infrastructure.EFCore
{
    internal class DiscountContextDesignFactory : IDesignTimeDbContextFactory<DiscountContext>
    {
        public DiscountContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<DiscountContext>();

            optionsBuilder.UseSqlServer("Server=DESKTOP-43K6HOP\\ADMIN;Database=PharmaPlusDB;User Id=admin;Password=alireza1382;TrustServerCertificate=True;");

            return new DiscountContext(optionsBuilder.Options);
        }
    }
}
