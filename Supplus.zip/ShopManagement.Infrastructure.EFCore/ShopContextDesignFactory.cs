﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace ShopManagement.Infrastructure.EFCore
{
    public class ShopContextDesignFactory : IDesignTimeDbContextFactory<ShopContext>
    {
        public ShopContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ShopContext>();

            optionsBuilder.UseSqlServer("Server=DESKTOP-43K6HOP\\ADMIN;Database=PharmaPlusDB;User Id=admin;Password=alireza1382;TrustServerCertificate=True;");

            return new ShopContext(optionsBuilder.Options);
        }
    }
}
