﻿namespace _0_Framework.Application
{
    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public T? Data { get; set; }
        public Dictionary<string, string[]>? Errors { get; set; }

        public static ApiResponse<T> Ok(T data, string message = "عملیات با موفقیت انجام شد")
            => new() { Success = true, Message = message, Data = data };

        public static ApiResponse<T> Fail(string message, Dictionary<string, string[]>? errors = null)
            => new() { Success = false, Message = message, Errors = errors };
    }

}