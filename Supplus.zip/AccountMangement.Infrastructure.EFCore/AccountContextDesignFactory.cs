﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
namespace AccountManagement.Infrastructure.EFCore
{
    public class AccountContextDesignFactory : IDesignTimeDbContextFactory<AccountContext>
    {
        public AccountContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<AccountContext>();

            optionsBuilder.UseSqlServer("Server=DESKTOP-43K6HOP\\ADMIN;Database=PharmaPlusDB;User Id=admin;Password=alireza1382;TrustServerCertificate=True;");

            return new AccountContext(optionsBuilder.Options);
        }
    }
}
