﻿using InventoryMangement.Infrastructure.EFCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace InventoryManagement.Infrastructure.EFCore
{
    public class InventoryContextDesignFactory : IDesignTimeDbContextFactory<InventoryContext>
    {
        public InventoryContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<InventoryContext>();

            optionsBuilder.UseSqlServer("Server=DESKTOP-43K6HOP\\ADMIN;Database=PharmaPlusDB;User Id=admin;Password=alireza1382;TrustServerCertificate=True;");

            return new InventoryContext(optionsBuilder.Options);
        }
    }
}
